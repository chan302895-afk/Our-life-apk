package com.ourlife.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    LifeView view;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        view = new LifeView(this);
        setContentView(view);
    }

    static class LifeView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        int page = 0;
        String[] tabs = {"⌂\nHome","◉\nFinance","▣\nBusiness","♡\nLife","☰\nMore"};
        int pink = Color.rgb(224,135,165);
        int ink = Color.rgb(65,60,68);
        int bg = Color.rgb(255,248,251);

        LifeView(Context c) {
            super(c);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            setBackgroundColor(bg);
        }

        void text(Canvas c, String s, float x, float y, float size, int color, boolean bold) {
            p.setTextSize(size);
            p.setColor(color);
            p.setTypeface(Typeface.create("sans", bold ? Typeface.BOLD : Typeface.NORMAL));
            c.drawText(s, x, y, p);
        }

        void round(Canvas c, float l,float t,float r,float b,int color,float rad) {
            p.setColor(color);
            c.drawRoundRect(l,t,r,b,rad,rad,p);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            c.drawColor(bg);

            // Header
            text(c, "OUR LIFE ♡", 28, 48, 28, ink, true);
            text(c, "Together • Grow • Remember", 30, 72, 13, Color.rgb(145,125,138), false);
            text(c, "မင်္ဂလာနံနက်ခင်းပါ", w-175, 42, 13, pink, true);

            if(page==0) home(c,w,h);
            else if(page==1) finance(c,w,h);
            else if(page==2) business(c,w,h);
            else if(page==3) life(c,w,h);
            else more(c,w,h);

            // Bottom navigation
            round(c, 12, h-78, w-12, h-12, Color.WHITE, 24);
            float cell=w/5f;
            for(int i=0;i<5;i++){
                float x=cell*i+cell/2;
                int col=(page==i)?pink:Color.rgb(135,128,138);
                p.setTextAlign(Paint.Align.CENTER);
                text(c, tabs[i].split("\n")[0], x, h-48, 22, col, true);
                text(c, tabs[i].split("\n")[1], x, h-27, 10, col, page==i);
            }
            p.setTextAlign(Paint.Align.LEFT);
        }

        void card(Canvas c,float l,float t,float r,float b,int color,String title,String value,String sub){
            round(c,l,t,r,b,color,20);
            text(c,title,l+18,t+30,14,ink,true);
            text(c,value,l+18,t+62,22,ink,true);
            text(c,sub,l+18,t+84,11,Color.rgb(120,112,120),false);
        }

        void home(Canvas c,float w,float h){
            text(c,"ဒီနေ့ စာရင်းအခြေအနေ",28,116,18,ink,true);
            float gap=10, cw=(w-56-gap)/2;
            card(c,28,132,28+cw,225,Color.rgb(232,249,239),"ဒီနေ့ ဝင်ငွေ","Ks 380,000","↑ ဝင်ငွေ");
            card(c,38+cw,132,w-28,225,Color.rgb(255,234,241),"ဒီနေ့ ထွက်ငွေ","Ks 165,000","↓ ထွက်ငွေ");
            card(c,28,237,28+cw,330,Color.rgb(232,244,255),"ဒီနေ့ စုငွေ","Ks 50,000","စုဆောင်းမှု");
            card(c,38+cw,237,w-28,330,Color.rgb(244,237,255),"လက်ကျန်ငွေ","Ks 165,000","လက်ကျန်");

            round(c,28,348,w-28,448,Color.WHITE,20);
            text(c,"ရည်မှန်းချက်",46,380,15,ink,true);
            text(c,"စုငွေရည်မှန်းချက် (2026)",46,403,12,Color.DKGRAY,false);
            text(c,"35%",w-75,380,18,pink,true);
            round(c,46,414,w-46,424,Color.rgb(238,226,232),8);
            round(c,46,414,46+(w-92)*.35f,424,pink,8);
            text(c,"Ks 3,500,000 / Ks 10,000,000",46,442,11,Color.GRAY,false);

            round(c,28,462,w-28,540,Color.rgb(255,243,247),20);
            text(c,"♡  လှူဒါန်းမှု",46,493,15,ink,true);
            text(c,"ဤလ စုစုပေါင်း",46,516,12,Color.GRAY,false);
            text(c,"Ks 120,000",w-145,507,18,pink,true);
        }

        void finance(Canvas c,float w,float h){
            text(c,"Finance",28,116,22,ink,true);
            card(c,28,135,w-28,220,Color.rgb(232,249,239),"စုစုပေါင်း ဝင်ငွေ","Ks 4,250,000","ဤလ");
            card(c,28,232,w-28,317,Color.rgb(255,234,241),"စုစုပေါင်း ထွက်ငွေ","Ks 2,980,000","ဤလ");
            card(c,28,329,w-28,414,Color.rgb(232,244,255),"စုဆောင်းငွေ","Ks 1,270,000","ဤလ");
            round(c,28,430,w-28,535,Color.WHITE,20);
            text(c,"ငွေစာရင်း",46,462,16,ink,true);
            text(c,"+ ဝင်ငွေထည့်ရန်",46,493,14,pink,true);
            text(c,"− ထွက်ငွေထည့်ရန်",w/2+5,493,14,pink,true);
            text(c,"ရည်မှန်းချက် / စုငွေ / လှူဒါန်းမှု",46,520,12,Color.GRAY,false);
        }

        void business(Canvas c,float w,float h){
            text(c,"လုပ်ငန်းများ (10 ခု)",28,116,22,ink,true);
            String[] names={"လုပ်ငန်း 1","လုပ်ငန်း 2","လုပ်ငန်း 3","လုပ်ငန်း 4","လုပ်ငန်း 5"};
            String[] profits={"Ks 320,000","Ks 250,000","Ks 180,000","Ks 140,000","Ks 120,000"};
            for(int i=0;i<5;i++){
                float y=135+i*72;
                round(c,28,y,w-28,y+60,Color.WHITE,18);
                text(c,"▣",48,y+38,22,pink,true);
                text(c,names[i],82,y+27,14,ink,true);
                text(c,"အမြတ်  "+profits[i],82,y+48,12,Color.GRAY,false);
                text(c,"›",w-52,y+38,24,Color.GRAY,false);
            }
            text(c,"+ လုပ်ငန်းအသစ်ထည့်ရန်",28,510,14,pink,true);
        }

        void life(Canvas c,float w,float h){
            text(c,"Life",28,116,22,ink,true);
            card(c,28,135,w-28,225,Color.rgb(255,243,247),"နေ့စဉ်မှတ်တမ်း","3 / 8","ဒီနေ့လုပ်ဆောင်ချက်များ");
            card(c,28,237,w-28,327,Color.rgb(244,237,255),"အမှတ်တရများ","12","ဓာတ်ပုံ / မှတ်စု");
            card(c,28,339,w-28,429,Color.rgb(232,244,255),"အလှူအတန်း","Ks 300,000","ဤလစုစုပေါင်း");
            round(c,28,445,w-28,535,Color.WHITE,20);
            text(c,"♡ Together • Grow • Remember",46,482,15,pink,true);
            text(c,"အတူတူရှိမယ် • အတူတူတိုးတက်မယ်",46,507,11,Color.GRAY,false);
        }

        void more(Canvas c,float w,float h){
            text(c,"More",28,116,22,ink,true);
            String[] items={"⚙  Settings","☁  Backup & Restore","🔔  Notifications","🔒  Privacy","ℹ  About OUR LIFE"};
            for(int i=0;i<items.length;i++){
                float y=135+i*66;
                round(c,28,y,w-28,y+54,Color.WHITE,18);
                text(c,items[i],48,y+34,14,ink,false);
                text(c,"›",w-52,y+35,22,Color.GRAY,false);
            }
            text(c,"Version 1.0",28,500,11,Color.GRAY,false);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float h=getHeight(), w=getWidth();
            if(e.getY()>h-95){
                int i=(int)(e.getX()/(w/5f));
                if(i>=0 && i<5){ page=i; invalidate(); }
            }
            return true;
        }
    }
}
