# OUR LIFE

Together • Grow • Remember

Personal life-management Android app.

## Main sections
- Home
- Finance
- Business
- Life
- More

## Build APK with GitHub Actions
1. Upload the project files to the repository.
2. Open **Actions**.
3. Select **Build OUR LIFE APK**.
4. Run the workflow.
5. Download the `OUR-LIFE-debug-apk` artifact.

The project uses a simple Android custom View so it has no third-party UI dependencies.
